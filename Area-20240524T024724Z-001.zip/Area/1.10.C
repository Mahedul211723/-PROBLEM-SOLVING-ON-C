
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,c,s,A;
    printf("Enter the value of a:");
    scanf("%f" ,&a);
    printf("Enter the value of b:");
    scanf("%f",&b);
    printf("Enter the value of c:");
    scanf("%f",&c);
    s=(a+b+c)/2;
    A=sqrt(s * (s-a)*(s-b)*(s-c));
    printf("Area of the triangle : %f ",A);

    return 0;
}
