#include <stdio.h>
#include<math.h>
#define pi 3.1416

int main()

{
    float x1=0,y1=0,x2=4,y2=5,r,perimeter,area;
    r=sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    perimeter=2*pi*r;
    area=pi*pow(r,2);
    printf("Perimetre = %f \nArea = %f",perimeter, area);

    return 0;


}
