#include<stdio.h>
#include<math.h>
#define pi 3.1416

int main()

{
    float x1=2,y1=2,x2=5,y2=6,D,r,Area;
    D=sqrt(pow((x2-x1),2)+pow((y2-y1),2));
    r=D/2;
    Area=pi*pow(r,2);
    printf("Area of the cicle = %f", Area);

    return 0;
}
