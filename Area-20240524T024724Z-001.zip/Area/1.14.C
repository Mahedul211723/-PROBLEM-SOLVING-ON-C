#include<stdio.h>
#include<stdlib.h>

int main()
{
    int a=5,b=8,c=18;
    printf("%dx + %dy = %d",a, b, c);
    return 0;


}
