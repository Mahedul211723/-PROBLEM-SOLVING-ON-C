#include<stdio.h>

int main()
{
    float x,y,sum,difference,product,division;
    printf("x =");
    scanf("%f",&x);
    printf("y =");
    scanf("%f",&y);

    sum=x+y;
    difference=x-y;
    product=x*y;
    division=x/y;
    printf("Sum %f \nDifference %f \nProduct %f \nDivision %f",sum,difference,product,division);
    return 0;

}
