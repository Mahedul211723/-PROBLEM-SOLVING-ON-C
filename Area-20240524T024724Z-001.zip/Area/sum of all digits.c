include<stdio.h>
  int main()
  {
      int num,rem,result=0;
      printf("Enter the number:");
      scanf("%d",&num);
      for(;num!=0;num=num/10)
      {
          rem=num%10;
          result=result+pow(rem,2);
      }
      printf("%d",result);
  }
