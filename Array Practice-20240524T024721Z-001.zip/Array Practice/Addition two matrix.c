#include <stdio.h>
#include <stdlib.h>

int main()
{
   int i,j,r1,c1,r2,c2,mat1[100][100],mat2[100][100],mat3[100][100];
   printf("Inter the dimension of mat 1:");
   scanf("%d %d",&r1,&c1);
   printf(" Inter the dimension of matrics 2:");
   scanf("%d %d",&r2,&c2);
   if((r1==r2) && (c1==c2))

   {
       printf("inter the mat1:\n");
       for(i=0;i<r1;i++)
       {
           for(j=0;j<c1;j++)
           { printf(" Inter element of: %d%d \n",i+1,j+1);
               scanf("%d",&mat1[i][j]);
           }
       }

        printf("inter the mat2:\n");
       for(i=0;i<r2;i++)
       {
           for(j=0;j<c2;j++)
           { printf(" Inter element of: %d%d \n ",i+1,j+1);
               scanf("%d",&mat2[i][j]);
           }
       }

        for(i=0;i<r2;i++)
       {
           for(j=0;j<c2;j++)
           {
            mat3[i][j]=mat1[i][j]+mat2[i][j];
            printf("%d",mat3[i][j]);
            printf(" ");
           }
           printf("\n");

       }

   }
   else
    printf("Imposible to add two mat!");


    return 0;
}


