#include<stdio.h>
#include<conio.h>

int CheckIdentityMat(int n, int arr[n][n]){
    int i, j;
    for(i = 0; i < n; i++){
        for(j = 0; j < n; j++){
            if((i != j && arr[i][j] != 0) || (i == j &&  arr[i][j] != 1)){
                return 0;
            }
        }
    }
    return 1;
}

int main(){
    int i, j, n;
    printf("n = ");
    scanf("%d", &n);
    int mat[n][n];
    for(i = 0; i < n; i++){
        for(j = 0; j < n; j++){
            scanf("%d", &mat[i][j]);
        }
    }
    if(CheckIdentityMat(n, mat) == 0){
        printf("Not Identity Matrix.");
    }
    else{
        printf("Identity Matrix");
    }
    return 0;
}
