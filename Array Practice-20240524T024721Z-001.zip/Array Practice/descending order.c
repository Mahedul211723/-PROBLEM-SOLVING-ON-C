#include <stdio.h>


void mergeArrays(int arr1[], int arr2[], int arr3[], int s1, int s2) {
    int i = 0, j = 0, k = 0;

    // Merge until one of the arrays is exhausted
    while (i < s1 && j < s2) {
        if (arr1[i] >= arr2[j]) {
            arr3[k++] = arr1[i++];
        } else {
            arr3[k++] = arr2[j++];
        }
    }

    // Copy remaining elements of arr1, if any
    while (i < s1) {
        arr3[k++] = arr1[i++];
    }

    // Copy remaining elements of arr2, if any
    while (j < s2) {
        arr3[k++] = arr2[j++];
    }
}

// Function to sort array in descending order
void sortDescending(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] < arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int arr1[100], arr2[100], arr3[200];
    int s1, s2, s3;

    printf("\nMerge two arrays of same size sorted in descending order.\n");
    printf("------------------------------------------------------------\n");

    printf("Input the number of elements to be stored in the first array: ");
    scanf("%d", &s1);

    printf("Input %d elements in the array:\n", s1);
    for (int i = 0; i < s1; i++) {
        printf("element - %d : ", i);
        scanf("%d", &arr1[i]);
    }

    printf("Input the number of elements to be stored in the second array: ");
    scanf("%d", &s2);

    printf("Input %d elements in the array:\n", s2);
    for (int i = 0; i < s2; i++) {
        printf("element - %d : ", i);
        scanf("%d", &arr2[i]);
    }

    // Merge the two arrays
    s3 = s1 + s2;
    mergeArrays(arr1, arr2, arr3, s1, s2);

    // Sort the merged array in descending order
    sortDescending(arr3, s3);

    // Print the merged array in descending order
    printf("\nThe merged array in descending order is:\n");
    for (int i = 0; i < s3; i++) {
        printf("%d   ", arr3[i]);
    }
    printf("\n\n");

    return 0;
}


