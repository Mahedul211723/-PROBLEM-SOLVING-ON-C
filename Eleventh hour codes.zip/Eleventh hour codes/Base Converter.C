#include <stdio.h>
#include <conio.h>

void convertBase(int num, int base) {
    int remainder;
    if(num == 0) {
        return;
    }
    else {
        convertBase(num / base, base);
        remainder = num % base;
        if(remainder < 10)
            printf("%d", remainder);
        else
            printf("%c", remainder + 55);
    }
}

int main() {
    int num, base;
    printf("Enter a decimal number: ");
    scanf("%d", &num);
    printf("Enter the base: ");
    scanf("%d", &base);
    if(base < 2 || base > 36) {
        printf("Invalid base! Enter a base between 2 and 36.\n");
    }
    else {
        printf("The number in base %d is: ", base);
        convertBase(num, base);
        printf("\n");
    }
    getch();
    return 0;
}
