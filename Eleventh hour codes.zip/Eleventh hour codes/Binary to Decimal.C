#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>
int main()
{
    char bin[10000];
    int i, p, len, dec = 0;
    printf("Enter a binary number: ");
    scanf("%s", bin);
    len = strlen(bin);
    p = len - 1;
    for(i = 0; i < len; i++){
        if(bin[i] > '1'){  //'0' & '1' represents characters which are representing ASCII codes.
            printf("Invalid Input.");
            return 0;
        }
        else{
            dec += (bin[i] - '0') * pow(2, p);  //'0' � '0' = 48  � 48 = 0 & '1' � '0' = 49  � 48 = 1
            p--;
        }
    }
    printf("Equivalent decimal value is: %d", dec);
    getch();
    return 0;
}
