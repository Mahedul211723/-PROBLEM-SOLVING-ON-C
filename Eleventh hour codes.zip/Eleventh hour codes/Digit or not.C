#include<stdio.h>

int isdig(char x){
    if(x >= 48 && x<= 57){
        return 1;
    }
    else{
        return 0;
    }
}

int main(){
    char m;
    printf("Input: ");
    m = getchar();
    int f = isdig(m);
    if(f == 1){
        printf("Digit");
    }
    else{
        printf("Not Digit");
    }
    return 0;

}
