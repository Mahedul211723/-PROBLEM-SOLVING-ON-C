#include<stdio.h>

double fact(int x){

int i, product;

product = 1;

    if(x == 0 || x ==1){

    product = 1;

    }

       else if(x > 1){

         product = x;

            for(i = x-1; i >= 1; i--){

                product = product * i;

            }
       }

        else if(x < 0){

               printf("Invalid Input.");

        }

return product;

}

int main(){
    double  p, sum = 0, n;
    int i;
    printf("n = ");
    scanf("%lf", &n);
    for(i = 1; i <= n; i+= 2){
        p = 1/fact(i);
        sum += p;
    }
    printf("\nFactrorial = %lf", fact(n));
    printf("\nSum of the series: %lf", sum);
}

