#include <stdio.h>
#include <conio.h>

int main() {
    int r1, c1, r2, c2, row, column;

    printf("Enter dimensions of 1st Matrix:\n");
    printf("r1 = ");
    scanf("%d", &r1);
    printf("c1 = ");
    scanf("%d", &c1);
    printf("Enter dimensions of 2nd Matrix:\n");
    printf("r2 = ");
    scanf("%d", &r2);
    printf("c2 = ");
    scanf("%d", &c2);

    if (c1 != r2) {
        printf("Invalid dimension! Matrices cannot be multiplied.\n");
        return 0; // Exit the program
    }

    row = r1;
    column = c2;

    int mat1[r1][c1], mat2[r2][c2], result[row][column];

    printf("\nEnter elements of the first matrix:\n");
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c1; ++j) {
            printf("Enter a%d%d: ", i + 1, j + 1);
            scanf("%d", &mat1[i][j]);
        }
    }

    printf("\nEnter elements of the second matrix:\n");
    for (int i = 0; i < r2; ++i) {
        for (int j = 0; j < c2; ++j) {
            printf("Enter b%d%d: ", i + 1, j + 1);
            scanf("%d", &mat2[i][j]);
        }
    }

    // Initialize the entries of the result matrix as 0
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < column; ++j) {
            result[i][j] = 0;
        }
    }

    // Multiply matrices and store the result
    for (int i = 0; i < r1; ++i) {
        for (int j = 0; j < c2; ++j) {
            for (int k = 0; k < c1; ++k) {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }

    // Display the result
    printf("\nOutput Matrix:\n");
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < column; ++j) {
            printf("%d  ", result[i][j]);
            if (j == column - 1) {
                printf("\n");
            }
        }
    }

    getch();
    return 0;
}
