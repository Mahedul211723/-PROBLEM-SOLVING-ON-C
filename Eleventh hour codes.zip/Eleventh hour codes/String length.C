#include <stdio.h>

    int string_length(char str[]){
        int i, length = 0;
        for(i = 0; str[i] != '\0'; i++) {
                length++;
        }
        return length;
    }
    int main()
{
    char string[1000];
    int length;
    while(1 == scanf("%s", string)){
    length = string_length(string);
    printf("length: %d\n\n", length);
    }
    return 0;
}
