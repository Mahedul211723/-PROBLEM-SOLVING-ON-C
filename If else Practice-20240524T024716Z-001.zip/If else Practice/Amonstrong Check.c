
#include<stdio.h>
#include<math.h>
int main()
{
    int n,a,b,c,d,e,f;
    printf("Enter the number:");
    scanf("%d",&n);
    e=n;
    a=n%10;
    n=n/10;
    b=n%10;
    n=n/10;
    c=n%10;
    n=n/10;
    d=n%10;
    f=pow(a,4)+pow(b,4)+pow(c,4)+pow(d,4);
    if(e==f)
        printf("Armstrong");
    else
        printf("Not Armstrong");



}
