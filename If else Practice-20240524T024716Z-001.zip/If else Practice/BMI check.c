#include<stdio.h>
int main()
{
    float w,h,BMI,c,a;
    printf("input weight:");
    scanf("%f",&w);
    printf("input height in foot:");
    scanf("%f",&h);
     printf("input height in inch:");
    scanf("%f",&a);
    c=h*0.305+a*0.0254;
    BMI=w/pow(c,2);
    if(BMI<18.5)
        printf("Underweight");
    if(BMI>=18.5 && BMI<24.9)
    printf("Normal");
    if(BMI>=25 && BMI<40)
        printf("Overweight");
    if(BMI>40)
        printf("Obesity�Class");
}

