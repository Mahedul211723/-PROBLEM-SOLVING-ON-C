#include<stdio.h>
  int main()
  {
      float a,b;
      printf("Enter the unit:");
      scanf("%f",&a);
      if(a<60)
      {
          printf("Invalid input");
          return 1;
      }
      if(a<100)
      {
          b=a*2.5;
          printf("%.2f",b);
      }
       else if(a>=100 && a<229)

      {
          b=a*3.5;
          printf("%.2f",b);
      }
      else if(a>=230 && a<250)

      {
          b=a*3.5;
          printf("%.2f",b+b*0.12);
      }
      else if(a>=250 && a<400)

      {
          b=a*4.20;
          printf("%f",b+b*0.12);
      }
       else

      {
          b=a*5;
          printf("%f",b+b*0.12);
      }
