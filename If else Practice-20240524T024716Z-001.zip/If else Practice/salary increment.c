
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int salary;
    printf("Enter the salary: ");
    scanf("%d",&salary);
    (salary<10000)?printf("increment 10 percentage is:%d",salary*10/100):0;
    (salary>=10000 && salary<=20000)?printf("increment 8 percentage is:%d",salary*8/100):0;
    (salary>=20000 && salary<=30000)?printf("increment 6 percentage is:%d",salary*6/100):0;
    (salary>30000)?printf("increment 4 percentage is:%d",salary*4/100):0;

����return�0;
}
