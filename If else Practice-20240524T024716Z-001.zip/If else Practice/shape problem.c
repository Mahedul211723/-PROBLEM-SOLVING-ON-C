#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,c,d;
    printf("Enter the value of a:");
    scanf("%d",&a);
    printf("Enter the value of b:");
    scanf("%d",&b);
    printf("Enter the value of c:");
    scanf("%d",&c);
    printf("Enter the value of d:");
    scanf("%d",&d);
    if(a==b&&b==c&&c==d&&d==a)
    {
        printf("square");
    }
    else if(a==c&&b==d)
    {
        printf("rectangular");

    }
    else if(a+b+c>d && a+c+d>b && b+c+d>a && a+b+d>c)
    {
        printf("quadrangle");
    }
    else
        printf("banana");

    return 0;
}
